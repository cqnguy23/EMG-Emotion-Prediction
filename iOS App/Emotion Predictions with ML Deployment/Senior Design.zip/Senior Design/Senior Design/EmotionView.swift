//
//  EmotionView.swift
//  Senior Design
//
//  Created by Tom Nguyen on 10/25/20.
//  Copyright © 2020 tomnguyen. All rights reserved.
//

import UIKit

class EmotionView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
